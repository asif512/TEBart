<template>
  <div class="home-view">
    <div class="content">
      <h6 class="large-text">CREATE UNIQUE ART</h6>
      <p class="medium-text">
        Use generative AI to build your own art portfolio
      </p>
    </div>
  </div>
</template>

<script>
export default {
  name: "HomeView",
  components: {},
};
</script>

<style scoped>
.content {
  margin-top: 4rem;
}
.large-text {
  font-size: 36px;
  margin: 0 0 10px 0;
  padding: 0;
  color: #444;
  letter-spacing: 0.01rem;
  word-spacing: 0.1rem;
}
.medium-text {
  font-size: 26px;
  margin: 0;
  padding: 0;
  color: #444;
  letter-spacing: 0.01rem;
  word-spacing: 0.1rem;
}
</style>
